package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class JavaConfig {
	
	@Bean   // convierte el objeto Java en un bean de Spring
	// El id del bean es el nombre del metodo
	RestTemplate restTemplate() {
		return new RestTemplate();  // retornar un objeto Java
	}

}
