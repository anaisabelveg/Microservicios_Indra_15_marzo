package es.indra.rest;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;

@RestController
public class PedidosREST {
	
	@Autowired  // No permite especificar el bean a inyectar
	// 1ª solucion: @Primary	
	// 2ª solucion: @Qualifier(nombre_bean)
	@Qualifier("feign")
	// 3ª solucion:  sustituir @Autowired por @Resource
	//@Resource(name = "feign")
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/4/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}

}
