INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$5TYb1Sz/aGRqXUQUcKkWPOua92l/XeMIvr1cujKojikd1DrNN22GC', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$dawpAkSmpjr1BsDu9bA.l.wEFonF8PoFoNjQ.o330.1DWn0M82E1m', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles(nombre) values ('ROLE_USER');
INSERT INTO roles(nombre) values ('ROLE_ADMIN');

INSERT INTO usuarios_roles(usuario_id, role_id) values (1,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,2);