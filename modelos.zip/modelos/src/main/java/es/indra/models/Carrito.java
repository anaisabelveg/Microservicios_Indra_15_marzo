package es.indra.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data   // getter, setter, constructor completo, equals y hashcode, toString
@NoArgsConstructor   // Constructor por defecto
public class Carrito implements Serializable{

	//@Id no se necesita
	private String id;
	private String usuario;
	private List<Pedido> contenido = new ArrayList<Pedido>();
	private double importe;
	
	
	// Necesitamos un constructor sin el id porque lo genera Mongo al persistir el documento
	public Carrito(String usuario, List<Pedido> contenido, double importe) {
		super();
		this.usuario = usuario;
		this.contenido = contenido;
		this.importe = importe;
	}
	
}
