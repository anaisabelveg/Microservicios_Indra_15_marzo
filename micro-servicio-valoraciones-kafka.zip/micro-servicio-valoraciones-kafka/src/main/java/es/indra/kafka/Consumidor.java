package es.indra.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumidor {
	
	// Si escucho de varios topics @KafkaListener(topics = {"topic1", "topic2", "topic3"})
	@KafkaListener(topics = "indra-cluster")
	public void recibirComentario(String comentario) {
		System.out.println("**********************************");
		System.out.println("Comentario recibido: " + comentario);
		System.out.println("**********************************");
	}

}
