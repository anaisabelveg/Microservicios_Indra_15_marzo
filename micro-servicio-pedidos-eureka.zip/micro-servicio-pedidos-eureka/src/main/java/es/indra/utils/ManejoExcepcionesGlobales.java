package es.indra.utils;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import feign.FeignException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// Igual que con try-catch podemos tener multiples catch
	// Aqui podemos tener varios metodos que cada uno capture un tipo de excepcion
	
	// http://localhost:8002/crear/1234/cantidad/100
	@ExceptionHandler(FeignException.class)
	public ResponseEntity<String> errorValidacion2(FeignException ex){
		System.out.println("Error de validacion: " + ex.getMessage());
		return new ResponseEntity<>("ID producto no valido", HttpStatus.BAD_REQUEST);
	}
	
	// http://localhost:8002/crear/ttty/cantidad/100
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> error(Exception ex){
		System.out.println("Error: " + ex.getMessage());
		return new ResponseEntity<>("Ha ocurrido un error", HttpStatus.BAD_REQUEST);
	}

}
